
#IMPORTS/SETUP
############################################
from turtle import Turtle
############################################



#3. create another paddle
############################################
#inheriting the paddle class from the turtle class
class Paddle(Turtle):
#the position determines where the paddle actually is
    def __init__(self, position):
        super().__init__()
#adjusting the shape of the paddle
        self.shape("square")
#setting the paddle color
        self.color("white")
#making the size of the paddle
        self.shapesize(stretch_wid= 5, stretch_len= 1)
#setting the position of the paddle
        self.penup()
        self.goto(position)

#this was made using spaces instead of tabs and may be incorrect!!

#creating the function for the set below
    def go_up(self):
#moving the paddles position
        new_y = self.ycor() + 20
#allows the paddle to move vertically
        self.goto(self.xcor(), new_y)

#recreating the definition above to allow the paddle to go back down
    def go_down(self):
        new_y = self.ycor() -20 
        self.goto(self.xcor(), new_y)



############################################
############################################
############################################
############################################
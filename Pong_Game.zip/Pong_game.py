#Day_22

#CREATING A PONG  GAME
############################################
#TODOS

#1. create the screen
#2. create and move a paddle
#3. create another paddle
#4. create the ball and make it move
#5. detect collision with wall and bounce
#6. detect collision with paddle
#7. detect when paddle misses
#8. keep score
############################################


#IMPORTS/SETUP
############################################
from turtle import Turtle, Screen
from paddle import Paddle
from ball import Ball
from scoreboard import Scoreboard
import time
#setting up the screen
screen = Screen()

#setting the background color
screen.bgcolor("black")

#setting the screen width and height
screen.setup(width = 800, height = 600)
screen.title("Pong")
#turn off the beginning tracer to set the paddle in the right place
screen.tracer(0)

#setting the paddles from the paddle class for our game
r_paddle = Paddle((350, 0))
l_paddle = Paddle((-350, 0))
ball = Ball()
scoreboard = Scoreboard()
############################################


#2. create and move a paddle
############################################
paddle = Turtle()

#adjusting the shape of the paddle
paddle.shape("square")

#setting the paddle color
paddle.color("white")

#making the size of the paddle
paddle.shapesize(stretch_wid= 5, stretch_len= 1)

#setting the position of the paddle
paddle.penup()
paddle.goto(350, 0)

# #creating the function for the set below
# def go_up():
#     #moving the paddles position
#     new_y = paddle.ycor() + 20
#     #allows the paddle to move vertically
#     paddle.goto(paddle.xcor(), new_y)

# #recreating the definition above to allow the paddle to go back down
# def go_down():
#     new_y = paddle.ycor() -20 
#     paddle.goto(paddle.xcor(), new_y)



#getting the screen to listen to updates
screen.listen()
# screen.onkey(go_up, "Up")
# screen.onkey(go_down, "Down")
#getting the right paddle to move

screen.onkey(r_paddle.go_up, "Up")
screen.onkey(r_paddle.go_down, "Down")

#getting the left paddle to move
screen.onkey(l_paddle.go_up, "w")
screen.onkey(l_paddle.go_down, "s")
#creating a while loop to get the paddle to remain in position at the start
game_is_on = True
while game_is_on:
    #getting a delayed reaction from the ball
    time.sleep(0.01)
    screen.update()
    ball.move()

#detecting the collision with the wall
    if ball.ycor() > 280 or ball.ycor() > -280:
        #need to "bounce"
        ball.bounce_y()

#detect collision with paddle
    if ball.distance(r_paddle) < 50 and ball.xcor() > 320 or ball.distance(l_paddle) < 50 and ball.xcor() < -320:
        # print("made contact")
        ball.bounce_x()

#detect when r_paddle misses
    if ball.xcor() > 380:
        ball.reset_position()
        scoreboard.l_point()

#detect when l_paddle misses
    if ball.xcor() < -380:
        ball.reset_position()
        scoreboard.r_point()
        
    


############################################

############################################
############################################


# MANUALLY CLOSE SCREEN
############################################
screen.exitonclick
############################################



##########################################
#IMPORTS:
from turtle import Turtle

##########################################




##########################################
#CONSTANTS:
STARTING_POSITION = (0, -280) 
MOVE_DISTANCE = 10
FINISH_LINE_Y = 280
##########################################


#1. Move the turtle with keypress
##########################################
class Player(Turtle):

    def __init__(self):
        super().__init__()      #inherit the turtle class
        self.shape("turtle")
        self.penup()    #preventing the turtle from drawing
        self.go_to_start()
        self.setheading(90) #get turtle to face north (90 degrees)

#defining the go_up function
    def go_up(self):
        self.forward(MOVE_DISTANCE)

    def go_to_start(self):
        self.goto(STARTING_POSITION)

    def is_at_finish_line(self):
        if self.ycor() > FINISH_LINE_Y:
            return True
        else:
            return False


##########################################







##########################################
#TODOS#

#1. Move the turtle with keypress
#2. create and move the cars
#3. detect collision with car
#4. detect when turtle reaches the other side
#5. create a scoreboard
##########################################
#INITIAL SETUP

import time
from turtle import Screen
from player import Player
from car_manager import CarManager
from scoreboard import Scoreboard

screen = Screen()
screen.setup(width=600, height=600)
screen.tracer(0)
##########################################



#1. Move the turtle with keypress
##########################################
#create a player with the player class
player = Player()
car_manager = CarManager()
scoreboard = Scoreboard()

#get turtle to move
screen.listen()
#getting the turtle to move "up"
screen.onkey(player.go_up, "Up")
##########################################


#3. detect collision with car
##########################################

game_is_on = True
while game_is_on:
    time.sleep(0.1)
    screen.update()

    car_manager.create_car()
    car_manager.move_cars()

    #detect collision with car
    for car in car_manager.all_cars:
        if car.distance(player) < 20:
            game_is_on = False
            scoreboard.game_over()
##########################################

#4. detect when turtle reaches the other side
##########################################
#detect a successful crossing
if player.is_at_finish_line():
        player.go_to_start()
        car_manager.level_up()
        scoreboard.increase_level() 
##########################################


screen.exitonclick()









